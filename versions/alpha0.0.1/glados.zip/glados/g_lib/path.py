def path():
    from os import getcwd

    path = getcwd()

    return path