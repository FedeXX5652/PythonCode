from PIL.WmfImagePlugin import *
