from PIL.Hdf5StubImagePlugin import *
