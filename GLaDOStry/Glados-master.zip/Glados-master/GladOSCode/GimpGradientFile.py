from PIL.GimpGradientFile import *
