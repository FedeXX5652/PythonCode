from PIL.PpmImagePlugin import *
