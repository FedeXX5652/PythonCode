from PIL.GifImagePlugin import *
