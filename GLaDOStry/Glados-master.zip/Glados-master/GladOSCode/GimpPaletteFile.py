from PIL.GimpPaletteFile import *
