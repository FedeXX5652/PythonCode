from PIL.TgaImagePlugin import *
