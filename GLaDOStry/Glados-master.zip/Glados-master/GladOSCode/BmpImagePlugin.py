from PIL.BmpImagePlugin import *
