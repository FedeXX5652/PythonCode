from PIL.IcoImagePlugin import *
