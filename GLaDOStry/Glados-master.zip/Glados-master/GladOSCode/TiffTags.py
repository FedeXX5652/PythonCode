from PIL.TiffTags import *
