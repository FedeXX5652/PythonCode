from PIL.CurImagePlugin import *
